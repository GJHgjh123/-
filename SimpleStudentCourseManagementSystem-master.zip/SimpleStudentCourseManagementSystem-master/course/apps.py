from django.apps import AppConfig


class CourseConfig(AppConfig):
    name = 'course'
